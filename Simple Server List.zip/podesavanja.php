<?php 
/*---------------------------------------------------------------------------\
 |               Simple Server List (v1.0b) ©  2012        	            
 |                                                                           
 |            		  Script by Dusan Stojadinovic                		     
 |                                                                           
 |     Made 10. XI 2012.             Contact - uncut.wz@gmail.com          
\---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------\
 |               				Podesavanja    		                
\---------------------------------------------------------------------------*/


	// Naziv administrativnog foldera
	define('ADMIN', 		'admin');

	// Sifra admin panela
	define('SIFRA', 		'pass');

	// Naziv style fajla. style-blue.css | style-red.css | style.css
	define('STYLE', 		'style-blue.css');

	// Steam dugme 1 | 0
	define('STEAM', 		'0');


/*---------------------------------------------------------------------------\
 |               				Podesavanja		               
\---------------------------------------------------------------------------*/
?>